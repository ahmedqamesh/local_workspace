import numpy as np
import logging
from matplotlib import gridspec
import matplotlib.cbook as cbook
import matplotlib.image as image
from scipy import interpolate
#%matplotlib inline
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - [%(levelname)-8s] (%(threadName)-10s) %(message)s")
logger = logging.getLogger(__name__)
import pandas as pd
import csv
import matplotlib
from celluloid import Camera
import matplotlib.image as image
import math
#plt.style.use('ggplot')
directory = "Trimming_Test/"
PdfPages = PdfPages('../output_data/trimming_test' + '.pdf')


def plot_BandGap(directory = directory , chip_Id = ["chip_Id"],txt = ["txt"]):
    col_row = plt.cm.BuPu(np.linspace(0.3, 0.9, len(chip_Id)))
    for chip in chip_Id:
        fig = plt.figure()
        ax = fig.add_subplot(111)
        BG_hex = []
        BG_int = []
        BG_mv=[]
        Freq = []
        error = []
        file = chip+"_BandGap.csv" 
        with open(chip+"/"+file, 'r')as data:  # Get Data for the first Voltage
            reader = csv.reader(data)
            next(reader)
            print("plotting %s"%chip)
            for row in reader:
               BG_hex = np.append(BG_hex, row[0])
               BG_int = np.append(BG_int, int(row[0],16))
               BG_mv = np.append(BG_mv, float(row[1]))
               Freq = np.append(Freq, float(row[2]))
               error = np.append(error, float(row[3]))
        ax.errorbar(BG_mv,Freq,error,fmt='-o', label = chip, color=col_row[chip_Id.index(chip)])
        ax.grid(True)
        ax.legend() 
        ax.set_xlabel("BandGap voltage [mv]")
        ax.set_ylabel("Oscillator Frequency [MHz]")
        ax.set_title("BandGap configuration Vs Oscillator Frequency", fontsize=12)
        ax2 = ax.twiny()
        ax2.spines['bottom'].set_position(('outward', 50))
        ax2.set_xlabel("BandGap Trimming bits [hex]")
        #ax2.xaxis.set_ticks_position('bottom')
        ax2.set_xticks(range(0, len(BG_hex)))
        ax2.set_xticklabels(BG_hex)
        ax2.xaxis.set_label_coords(0.5, -0.5)
        ax2.set_xlim(ax.get_xlim())
    
        plt.savefig(chip+"/"+file+".png", bbox_inches='tight')
    
def plot_BandGap_All(directory = directory , chip_Id = ["chip_Id"],txt = ["txt"]):
    fig = plt.figure()
    ax = fig.add_subplot(111)
    col_row = plt.cm.BuPu(np.linspace(0.3, 0.9, len(chip_Id)))
    cmap = plt.cm.get_cmap('tab20', 16)
    for chip in chip_Id:
        BG_hex = []
        BG_int = []
        BG_mv=[]
        Freq = []
        error = []
        file = chip+"_BandGap.csv" 
        with open(chip+"/"+file, 'r')as data:  # Get Data for the first Voltage
            reader = csv.reader(data)
            next(reader)
            print("plotting %s"%chip)
            for row in reader:
               BG_hex = np.append(BG_hex, row[0])
               BG_int = np.append(BG_int, int(row[0],16))
               BG_mv = np.append(BG_mv, float(row[1]))
               Freq = np.append(Freq, float(row[2]))
               error = np.append(error, float(row[3]))
            ax.errorbar(BG_mv,Freq,error,fmt='-', label = chip)#, color=col_row[chip_Id.index(chip)])
            sc = ax.scatter(BG_mv, Freq, c=BG_int, cmap=cmap, s=50) 
    cbar = fig.colorbar(sc, ax=ax, orientation='vertical')
    cbar.set_ticks(np.linspace(0.5, len(BG_int), len(BG_int)+2))
    cbar.set_ticklabels(BG_hex)
    #cbar.ax.invert_xaxis()
    cbar.set_label("BandGap Trimming bits [hex]", labelpad=1, fontsize=10)   
    ax.tick_params(axis='x', labelrotation=90)   
    ax.grid(True)
    ax.legend() 
    ax.set_xlabel("BandGap voltage [mv]")
    ax.set_ylabel("Oscillator Frequency [MHz]")
    ax.set_title("BandGap configuration Vs Oscillator Frequency", fontsize=12)
    plt.tight_layout()
    plt.savefig("BandGap_Oscillation_All.png", bbox_inches='tight')
    PdfPages.savefig()
    


chip_Id = ["Chip2","Chip4", "Chip6_New","Chip7"]#,"Chip6_Old"] 
plot_BandGap(chip_Id = chip_Id)
plot_BandGap_All(chip_Id = chip_Id)
PdfPages.close()